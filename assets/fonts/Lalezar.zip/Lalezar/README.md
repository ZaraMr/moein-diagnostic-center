
# FontFa.com

Thank you for downloading the font from the FontFa.com site

All Right Reserved By Fontfa.com

# How to install fonts in Windows

Copy Font files to Addree > C:\Windows\Fonts

